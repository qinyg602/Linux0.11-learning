void disp_str(char * info);
void disp_color_str(char * info, int color);
void disp_int(unsigned long addr);

