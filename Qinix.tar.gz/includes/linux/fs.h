#ifndef _FS_H
#define _FS_H
#ifndef NULL
#define NULL ((void*)0)
#endif // NULL


#endif // _FS_H
